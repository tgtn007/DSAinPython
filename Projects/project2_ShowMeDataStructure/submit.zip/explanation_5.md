# Active Directory

## Data Structure 
The data structure used is linked list, to store all the information.

## Time Complexity
The time complexity is O(N) to iterate through all the nodes of the linked list.

## Space Complexity
The space complexity is O(N) that is size of the blockchain.