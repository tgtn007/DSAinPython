# LRU Cache

## Data Structure 
I am using dictionaries here to store the key valued pairs in it. I am removing and adding in the dictionary to perform
the use operation.

## Time Complexity
The time complexity of all the operations is O(1) time, as dictionaries takes constant time for lookup.

## Space Complexity
The worst case complexity will the linear that is the max capacity of LRU Cache.