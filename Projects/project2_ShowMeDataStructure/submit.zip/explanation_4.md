# Active Directory

## Data Structure 
There is no data structure used here, recursion was used to check all the groups and its subgroups, though we can say
stack was used as recursion uses stack.

## Time Complexity
The time complexity to find all the files is O(N) no of files it had to check in the given path's directory and all it's
subdirectories.

## Space Complexity
The worst case complexity will the linear that is number of groups inside one other to store it in recursion call stack.