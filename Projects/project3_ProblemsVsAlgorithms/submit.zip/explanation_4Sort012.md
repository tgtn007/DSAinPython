#Sort 0-1-2
## Approach
The main approach here is to put 0 and 2 into its right places which will automatically sort 1 into its right places.

## Time Complexity
The time complexity is O(N) as we are traversing the list only once.

## Space Complexity 
We didn't use any new additional data structures, so the space complexity of our approach is O(1).