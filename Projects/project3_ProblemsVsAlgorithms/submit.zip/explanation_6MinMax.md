#Min Max in a unsorted Array
##Approach
I used a single traversal to check all the elements in the array to find the largest and the smallest element.

## Time Complexity
The approach used takes O(N) time complexity as it traverses the list only once.

## Space Complexity
I am not using any additional data structure to store anything, therefore the space complexity of the program is
O(1)