#Autocomplete with Tries
## Approach
I used the concept of tries and recursion to input and then search an element in tries.

## Time Complexity 
The time complexity to insert an word is length of that word, that is O(N) time.

## Space Complexity 
The space complexity of the approach is O(M) that is number of nodes in the trie.