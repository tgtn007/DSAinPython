#Route Handler
## Approach
I used the concept of tries to insert and for lookup.

## Time Complexity 
The time complexity to insert an word is length of that word, that is O(N) time.

## Space Complexity 
The space complexity of the approach is O(M) that is number of nodes in the trie.